<?php
// Start error reporting (for debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database credentials
$servername = "localhost";
$username = "ssrvbrjj_cyber";
$password = "CWBG5KpxVLbzMjchkvvW";
$dbname = "ssrvbrjj_cyber";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve user inputs
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate inputs
    if (empty($email) || empty($password)) {
        echo "<script>alert('Email and password are required.'); window.history.back();</script>";
        exit();
    }

    // Check if the email exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    if (!$stmt) {
        die("Preparation failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "<script>alert('Email not found. Please register first.'); window.history.back();</script>";
        $stmt->close();
        $conn->close();
        exit();
    }

    $user = $result->fetch_assoc();
    // Verify the password
    if (password_verify($password, $user['password'])) {
        // Start session and store user data if needed
        session_start();
        $_SESSION['email'] = $user['email'];

        echo "<script>alert('Login successful!'); window.location.href='main.html';</script>";
    } else {
        echo "<script>alert('Incorrect password.'); window.history.back();</script>";
    }

    $stmt->close();
}

$conn->close();
?>
